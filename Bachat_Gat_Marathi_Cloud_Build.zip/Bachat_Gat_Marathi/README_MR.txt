माझा बचत गट — Android प्रकल्प

महत्त्वाचे:
या ZIP मध्ये Android Studio मधून APK तयार करण्यासाठीचा स्रोत प्रकल्प आणि ऑफलाइन मराठी ॲप आहे. हा ZIP स्वतः APK फाईल नाही. या वातावरणात Android SDK/Gradle build उपलब्ध नसल्याने येथे थेट इन्स्टॉल होणारी APK compile केलेली नाही.

APK तयार करण्यासाठी:
1. संगणकावर Android Studio स्थापित करा.
2. हा ZIP extract करा.
3. Android Studio > Open > Bachat_Gat_Marathi फोल्डर निवडा.
4. Gradle sync पूर्ण होऊ द्या; SDK 35 मागितल्यास Android SDK Platform 35 स्थापित करा.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) निवडा.
6. APK app/build/outputs/apk/debug/app-debug.apk येथे तयार होईल.
7. APK मोबाईलमध्ये पाठवा आणि Android Settings मध्ये त्या file manager/browser साठी “Install unknown apps” परवानगी देऊन install करा.

वैशिष्ट्ये:
- मराठी सभासद नोंदणी
- बचत जमा
- कर्जवाटप आणि वार्षिक व्याजदर
- हप्ते, मूळ रक्कम आणि व्याज वेगळे नोंदवणे
- बाकी कर्जाचा अंदाज
- JSON backup/restore आणि CSV export
- offline/local storage

डेटा:
डेटा ॲपच्या local storage मध्ये असतो. ॲप uninstall किंवा app data clear केल्यास डेटा नष्ट होऊ शकतो. नियमित बॅकअप घ्या.
कर्जातील व्याज गणना ही साध्या वार्षिक व्याजावर आधारित अंदाज आहे; गटाच्या नियमांनुसार पडताळणी करा.
